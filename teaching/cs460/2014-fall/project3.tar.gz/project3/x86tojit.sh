#!/bin/bash
set -e

if [ $# -ne 1 ]; then
	echo "Usage: $0 input.s" >&2
fi

file=`mktemp -t x86tojit.XXXXXX`
output=`mktemp -t x86tojit.XXXXXX`
trap "{ rm -f \"$file\" \"$output\"; exit; }" EXIT

cat <<EOF > "$file"
	.intel_syntax noprefix
	.text
	.globl	main
	.type	main, @function
main:
EOF
cat "$1" >> "$file"
cat <<EOF >> "$file"
	ud2
	.size	main, .-main
EOF
gcc -m32 -xassembler -o "$output" "$file"
objdump -Mintel -d "$output" | sed -En '
/<main>:/,/ud2/{
	/<main>:|ud2/d
	s/^[^\t]*\t(( ?[0-9a-f]{2})*) *\t(.*)$/\1\t\3/
	p
}'
