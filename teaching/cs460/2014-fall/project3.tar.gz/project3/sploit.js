print("Loading 'helper.js'");
var f = load('helper.js');
print(f(0x55aa));
// Uncomment and run ./target -m sploit.js to see the address space
// mapping.
// exploit(0);
