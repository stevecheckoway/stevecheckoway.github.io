function sploit(x) {
	if (x == 0)
		return 0;
	var y = x
		^ 0x12345678
		^ 0;
	return y;
}
sploit(0);
sploit // Return sploit function.
