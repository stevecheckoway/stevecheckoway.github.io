# ROP practice

Edit `main.c` and write your return-oriented program in terms of `X`, `Y`, and
`Z`---the addresses of global variables `x`, `y`, and `z`---and the 11
instruction sequences `seq[1]`, `seq[2]`, ..., `seq[11]`.

End your return-oriented program with `stop` to return to the `done` function.
`done` prints out the values of `x`, `y`, and `z`,

To run your return-oriented program, call
```
run(rop, x_value, y_value, z_value)
```
Only the first call to `run` will work as the `done` function exits
the program.

Build the program by running `make` and then run it via `./rop`.

You can debug the program by building and then running `gdb ./rop`.
