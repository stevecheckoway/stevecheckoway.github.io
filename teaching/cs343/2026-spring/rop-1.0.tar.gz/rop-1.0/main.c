#include <stdio.h>
#include <stdlib.h>

extern long seq[12];
static long x, y, z;

static void done(void) {
	printf("After:  x = %ld  y = %ld  z = %ld\n", x, y, z);
	exit(0);
}

static void run(long *rop, long start_x, long start_y, long start_z) {
	x = start_x;
	y = start_y;
	z = start_z;
	printf("Before: x = %ld  y = %ld  z = %ld\n", x, y, z);
	asm volatile("movq %0, %%rsp\n\tretq" :: "r"(rop) : "memory");
	exit(1);
}

int main() {
	const long X = (long)&x;
	const long Y = (long)&y;
	const long Z = (long)&z;
	const long stop = (long)done;

	long li_rop[] = {
		seq[6],
		seq[1],
		X - 32,
		seq[8],
		seq[2],
		1234,
		0,
		seq[9],
		seq[10],
		stop,
	};

	long move_rop[] = {
		// Write the MOVE gadget here.
		stop,
	};
	long load_rop[] = {
		// Write the LOAD gadget here.
		stop,
	};
	
	long store_rop[] = {
		// Write the STORE gadget here.
		stop,
	};

	long add_rop[] = {
		// Write the ADD gadget here.
		stop,
	};

	run(li_rop, 0, -182, 0);
	//run(move_rop, 42, 0, 0);
	//run(load_rop, Z, 0, 42);
	//run(store_rop, 42, Z, -1);
	//run(add_rop, 10, 20, 0);
	
	exit(1);
}
