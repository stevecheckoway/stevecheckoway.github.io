.intel_syntax noprefix
.section .note.GNU-stack,"",@progbits

.data
.global seq
seq: .quad 0, .L1, .L2, .L3, .L4, .L5, .L6, .L7, .L8, .L9, .L10, .L11

.text
.L1:
	pop	rsi
	ret

.L2:
	pop	rbx
	pop	rbp
	ret

.L3:
	add	rax, rcx
	ret

.L4:
	sub	rax, rbx
	ret

.L5:
	imul	rbx, rax
	ret

.L6:
	xor	rax, rax
	ret

.L7:
	and	rbx, qword ptr [rbp - 16]
	ret

.L8:
	or	rax, rsi
	ret

.L9:
	mov	rcx, rbx
	ret

.L10:
	mov	qword ptr [rax + 32], rcx
	ret

.L11:
	mov	rcx, qword ptr [rax]
	ret
